import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield

Item {
  id: root

  // ---- User options ----
  property bool hudEnabled: true
  property bool reticleEnabled: true
  property int refreshMs: 200
  property int decimalsMinutes: 2
  property real hudOpacity: 0.72
  property bool hudDraggable: true

  // Drag offsets
  property real hudOffsetX: 0
  property real hudOffsetY: 0

  // ---- Internal ----
  property var mw: iface.mainWindow()
  property var canvas: iface.mapCanvas()
  property var mapSettings: canvas ? canvas.mapSettings : null

  // Keep on top
  z: 999999

  Component.onCompleted: {
    updateHud()
    ticker.interval = refreshMs
    ticker.start()
  }

  function configure() { cfg.open(); }

  Dialog {
    id: cfg
    parent: mw ? mw.contentItem : undefined
    modal: true
    title: "Center DDM HUD"
    standardButtons: Dialog.Ok
    onAccepted: cfg.close()

    ColumnLayout {
      width: Math.min(parent.width * 0.9, 420)
      spacing: 10

      Switch { text: "Show coordinate HUD"; checked: hudEnabled; onToggled: hudEnabled = checked }
      Switch { text: "Show center reticle"; checked: reticleEnabled; onToggled: reticleEnabled = checked }
      Switch { text: "Allow dragging HUD"; checked: hudDraggable; onToggled: hudDraggable = checked }

      RowLayout {
        spacing: 10
        Label { text: "Refresh (ms)"; Layout.fillWidth: true }
        SpinBox {
          from: 80; to: 1000; value: refreshMs
          onValueModified: { refreshMs = value; ticker.interval = refreshMs; }
        }
      }

      RowLayout {
        spacing: 10
        Label { text: "Minutes decimals"; Layout.fillWidth: true }
        SpinBox {
          from: 0; to: 4; value: decimalsMinutes
          onValueModified: decimalsMinutes = value
        }
      }
    }
  }

  Timer {
    id: ticker
    repeat: true
    running: false
    onTriggered: updateHud()
  }

  function padLeft(s, width) {
    while (s.length < width) s = "0" + s;
    return s;
  }

  function toDDM(value, isLon) {
    var hemi = isLon ? (value < 0 ? "W" : "E") : (value < 0 ? "S" : "N");
    var av = Math.abs(value);
    var deg = Math.floor(av);
    var minutes = (av - deg) * 60.0;

    var degWidth = isLon ? 3 : 2;
    var degStr = padLeft(deg.toString(), degWidth);

    var minStr = minutes.toFixed(decimalsMinutes);
    if (minutes < 10) minStr = "0" + minStr;

    return {deg: degStr, min: minStr, hemi: hemi};
  }

  function updateHud() {
    if (!hudEnabled || !mapSettings) {
      hudText.text = "";
      return;
    }
    var c = mapSettings.center;
    if (!c) return;

    // For now: assume project CRS is EPSG:4326, or accept CRS units until we add reprojection.
    var lon = c.x;
    var lat = c.y;

    var la = toDDM(lat, false);
    var lo = toDDM(lon, true);

    hudText.text =
      la.deg + "° " + la.min + "′ " + la.hemi + "   " +
      lo.deg + "° " + lo.min + "′ " + lo.hemi;
  }

  // ---- Reticle ----
  Item {
    anchors.centerIn: parent
    width: 60
    height: 60
    visible: reticleEnabled
    z: 999998

    Canvas {
      anchors.fill: parent
      onPaint: {
        var ctx = getContext("2d");
        ctx.clearRect(0, 0, width, height);

        function drawCross(strokeStyle, lineWidth) {
          ctx.strokeStyle = strokeStyle;
          ctx.lineWidth = lineWidth;
          ctx.beginPath();
          ctx.moveTo(width/2, 6);
          ctx.lineTo(width/2, height-6);
          ctx.moveTo(6, height/2);
          ctx.lineTo(width-6, height/2);
          ctx.stroke();
        }

        drawCross("rgba(0,0,0,0.85)", 5);
        drawCross("rgba(255,255,255,0.95)", 2);

        ctx.fillStyle = "rgba(255,255,255,0.95)";
        ctx.beginPath();
        ctx.arc(width/2, height/2, 2.2, 0, Math.PI*2);
        ctx.fill();
      }
    }
  }

  // ---- Bottom-center HUD ----
  Rectangle {
    id: hudBox
    visible: hudEnabled
    color: Qt.rgba(0, 0, 0, hudOpacity)
    radius: 10
    z: 999999

    // bottom center + offsets
    anchors.horizontalCenter: parent.horizontalCenter
    anchors.bottom: parent.bottom
    anchors.bottomMargin: 18 + hudOffsetY
    x: (parent.width - width) / 2 + hudOffsetX

    // manual padding via content margins
    property int pad: Math.max(10, Math.round(parent.width / 60))
    property int fontPx: Math.max(16, Math.min(32, Math.round(parent.width / 18)))

    width: hudText.paintedWidth + pad * 2
    height: hudText.paintedHeight + pad * 2

    Text {
      id: hudText
      anchors.centerIn: parent
      color: "white"
      text: ""
      font.pixelSize: hudBox.fontPx
      font.bold: true
    }

    MouseArea {
      anchors.fill: parent
      enabled: hudDraggable
      cursorShape: Qt.OpenHandCursor
      property real sx
      property real sy

      onPressed: { sx = mouse.x; sy = mouse.y; cursorShape = Qt.ClosedHandCursor; }
      onReleased: cursorShape = Qt.OpenHandCursor
      onPositionChanged: {
        hudOffsetX += (mouse.x - sx);
        hudOffsetY += (mouse.y - sy);

        hudOffsetY = Math.max(-parent.height + 80, Math.min(0, hudOffsetY));
        hudOffsetX = Math.max(-parent.width/2 + 40, Math.min(parent.width/2 - 40, hudOffsetX));
      }
    }
  }
}