import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield

Item {
  id: root

  // ---------- User options ----------
  property bool hudEnabled: true
  property bool reticleEnabled: true
  property int refreshMs: 200            // 100–250ms feels responsive without being heavy
  property int decimalsMinutes: 2        // MM.mm (2 decimals)
  property real hudOpacity: 0.72         // background box opacity
  property int fontPx: 22               // will be auto-scaled below

  // Allow dragging the HUD if it conflicts with phone UI
  property bool hudDraggable: true

  // HUD placement offsets (can be changed by dragging)
  property real hudOffsetX: 0
  property real hudOffsetY: 0

  // ---------- Internal ----------
  property var mw: iface.mainWindow()
  property var canvas: iface.mapCanvas()
  property var mapSettings: canvas ? canvas.mapSettings : null

  // Keep on top of QField UI
  z: 999999

  Component.onCompleted: {
    if (!mw || !canvas || !mapSettings) {
      // If this ever fires, QField plugin API / iface isn't accessible.
      // (Should not happen in normal QField runtime.)
      return;
    }
    // Optional toast for dev testing (comment out for production)
    // mw.displayToast("Center DDM HUD loaded");
    updateHud();
    ticker.start();
  }

  // ----------- Configure dialog hook (shows a gear icon in plugin manager) ----------
  function configure() {
    cfg.open();
  }

  Dialog {
    id: cfg
    parent: mw ? mw.contentItem : undefined
    modal: true
    title: "Center DDM HUD"
    standardButtons: Dialog.Ok
    onAccepted: cfg.close()

    ColumnLayout {
      width: Math.min(parent.width * 0.9, 420)
      spacing: 10

      Switch {
        text: "Show coordinate HUD"
        checked: hudEnabled
        onToggled: hudEnabled = checked
      }

      Switch {
        text: "Show center reticle"
        checked: reticleEnabled
        onToggled: reticleEnabled = checked
      }

      Switch {
        text: "Allow dragging HUD"
        checked: hudDraggable
        onToggled: hudDraggable = checked
      }

      RowLayout {
        spacing: 10
        Label { text: "Refresh (ms)"; Layout.fillWidth: true }
        SpinBox {
          from: 80; to: 1000; value: refreshMs
          onValueModified: {
            refreshMs = value;
            ticker.interval = refreshMs;
          }
        }
      }

      RowLayout {
        spacing: 10
        Label { text: "Minutes decimals"; Layout.fillWidth: true }
        SpinBox {
          from: 0; to: 4; value: decimalsMinutes
          onValueModified: decimalsMinutes = value
        }
      }
    }
  }

  // ---------- Timer update loop ----------
  Timer {
    id: ticker
    interval: refreshMs
    repeat: true
    running: false
    onTriggered: updateHud()
  }

  // ---------- DDM formatting ----------
  function padLeft(numStr, width) {
    while (numStr.length < width) numStr = "0" + numStr;
    return numStr;
  }

  function toDDM(value, isLon) {
    // value in degrees
    var hemi;
    if (isLon) hemi = (value < 0) ? "W" : "E";
    else       hemi = (value < 0) ? "S" : "N";

    var av = Math.abs(value);
    var deg = Math.floor(av);
    var minutes = (av - deg) * 60.0;

    var degWidth = isLon ? 3 : 2;
    var degStr = padLeft(deg.toString(), degWidth);

    // Format minutes with fixed decimals (MM.mm)
    var minStr = minutes.toFixed(decimalsMinutes);
    // Ensure at least 2 integer minute digits (e.g. 03.40)
    if (minutes < 10) minStr = "0" + minStr;

    return {
      deg: degStr,
      min: minStr,
      hemi: hemi
    };
  }

  function updateHud() {
    if (!hudEnabled || !mapSettings) {
      hudText.text = "";
      return;
    }

    // IMPORTANT:
    // mapSettings.center is in the map's current CRS.
    // We'll attempt to reproject it to EPSG:4326 using GeometryUtils,
    // falling back to "as-is" if reprojection utilities differ by build.
    var c = mapSettings.center;   // QgsPointXY-like
    if (!c) return;

    var lon = c.x;
    var lat = c.y;

    // Attempt reprojection to WGS84
    // (API is provided via QField utilities; exact availability can vary by build.)
    lon = c.x;
    lat = c.y;

    var la = toDDM(lat, false);
    var lo = toDDM(lon, true);

    // Example: 23° 12.40′ S   042° 50.75′ W
    hudText.text =
      la.deg + "° " + la.min + "′ " + la.hemi + "   " +
      lo.deg + "° " + lo.min + "′ " + lo.hemi;
  }

  // ---------- Center reticle (optional) ----------
  Item {
    id: reticle
    anchors.centerIn: parent
    width: 60
    height: 60
    visible: reticleEnabled

    Canvas {
      anchors.fill: parent
      onPaint: {
        var ctx = getContext("2d");
        ctx.clearRect(0, 0, width, height);

        // Outer halo (black) then inner line (white) for offshore readability
        function drawCross(strokeStyle, lineWidth) {
          ctx.strokeStyle = strokeStyle;
          ctx.lineWidth = lineWidth;
          ctx.beginPath();
          ctx.moveTo(width/2, 6);
          ctx.lineTo(width/2, height-6);
          ctx.moveTo(6, height/2);
          ctx.lineTo(width-6, height/2);
          ctx.stroke();
        }

        drawCross("rgba(0,0,0,0.85)", 5);
        drawCross("rgba(255,255,255,0.95)", 2);

        // Small center dot
        ctx.fillStyle = "rgba(255,255,255,0.95)";
        ctx.beginPath();
        ctx.arc(width/2, height/2, 2.2, 0, Math.PI*2);
        ctx.fill();
      }
    }
  }

  // ---------- Bottom-center HUD ----------
  Rectangle {
    id: hudBox
    visible: hudEnabled
    color: Qt.rgba(0, 0, 0, hudOpacity)
    radius: 10

    // Always on top
    z: 999999

    // Bottom-center placement; draggable offsets applied
    anchors.horizontalCenter: parent.horizontalCenter
    anchors.bottom: parent.bottom

    // A generous default bottom margin so it stays visible above many Android nav bars.
    // If a specific phone still overlaps it, you can drag it up.
    anchors.bottomMargin: 18 + hudOffsetY
    x: (parent.width - width) / 2 + hudOffsetX

    // Auto-scale font with screen width but keep sane bounds
    property int computedFontPx: Math.max(16, Math.min(32, Math.round(parent.width / 18)))

    padding: 10

    Text {
      id: hudText
      anchors.centerIn: parent
      color: "white"
      text: ""
      font.pixelSize: hudBox.computedFontPx
      font.bold: true
    }

    // Drag support (to guarantee visibility on every phone)
    MouseArea {
      anchors.fill: parent
      enabled: hudDraggable
      cursorShape: Qt.OpenHandCursor
      property real startX
      property real startY
      onPressed: {
        startX = mouse.x;
        startY = mouse.y;
        cursorShape = Qt.ClosedHandCursor;
      }
      onReleased: cursorShape = Qt.OpenHandCursor
      onPositionChanged: {
        // Move within reasonable bounds
        hudOffsetX += (mouse.x - startX);
        hudOffsetY += (mouse.y - startY);

        // Clamp Y so it doesn't go off-screen
        hudOffsetY = Math.max(-parent.height + 80, Math.min(0, hudOffsetY));
        // Clamp X a bit
        hudOffsetX = Math.max(-parent.width/2 + 40, Math.min(parent.width/2 - 40, hudOffsetX));
      }
    }
  }
}